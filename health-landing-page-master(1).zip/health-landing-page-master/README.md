# Project Boilerplate

## Required Extensions

- Live Server

### Required npm package

SASS

```
npm i -g sass
```

#### How to compile sass

```
npm run sass
```

#### How to run the server

1. Right click inside index.html
2. Click Open with live server
